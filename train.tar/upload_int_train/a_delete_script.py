import os
import numpy as np

filepath = r'/HDD8T/2021StudentFile/fhy/DQN/gitcode/duo_multi/duo-opt-interposer-train'

file = os.listdir(filepath)

for pic in file:
    new_id = os.path.join(filepath,pic)
    print(new_id)
    if pic[0].isdigit():
        os.remove(new_id)
    else:
        print('baoliu')
