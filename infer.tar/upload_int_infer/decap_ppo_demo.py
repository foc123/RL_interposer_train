"""
A new ckt environment based on a new structure of MDP
"""
import gym
from gym import spaces
import time
import numpy as np
import random
import statistics
import os
import IPython
import itertools
import pickle
import os

NCOL, NROW, NCAP = 5, 5, 81
CAP_VAL = 1e-8
VDI_LOW = 0
VDI_HIGH = 100.
VDI_TARGET = 8e-10
NODE_LOC = [416, 1250, 2083, 2916, 3750, 4583, 5416, 6250, 7083, 7916, 8750, 9583]
PATH_PREFIX =  '/HDD8T/2021StudentFile/fhy/DQN/gitcode/base_paper_korean/RL_infer_int1/'

multi = 5
vdi_max = 0.0
vdi_min = 100.0
dcap_max = 0.0
dcap_min = 100.0
dcap_offset = 1.0e-9    # decap leakage cost offset
dcap_threshold = 10.0e-9   # decap leakage cost threshold


global dict_state


def run_os():
    
    pids = np.genfromtxt('source_choice')
    if os.getpid() not in pids:
        pids = np.append(pids,os.getpid())
    
    idx = np.where(pids == os.getpid())
        
    subs = int(idx[0] % multi)

    filename = 'interposer1_ac.sp' 
    with open(PATH_PREFIX + filename, 'r') as f:
        chiplet = f.read()
        chiplet = chiplet.replace(".include 'int_param_dcap.txt'", ".include '" + str(os.getpid()) + "_int_param_dcap.txt'")
        chiplet = chiplet.replace("wrdata test.txt vm(nd_pkg_pad)" , "wrdata " + str(os.getpid()) + "_freq_data.txt vm(nd_pkg_pad)")
        f.close()
        
        
    with open(PATH_PREFIX + str(os.getpid()) + '_' + filename, 'w') as f:
        f.write(chiplet)
        f.close()
        
    # add pid to the linux command
    os.system( 'ngspice ' + str(os.getpid()) + '_interposer1_ac.sp')


def readvdi(file):  # 读取csv中的vdi的数据，得到的是array数据，这里作为input
    zvdi = readresult(file)
    z = zvdi[:, 2]
    return z


def readresult(filename):
    a1 = np.genfromtxt(filename)
    return a1



class DecapPlaceParallel(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self, env_config):
        self.env_steps = 0  
        # stay, left, up, right, down = 0, 1, 2, 3, 4
        #self.st = 0
        self.vdi_min = 0
        self.vdi_max = 0

        self.action_meaning = [0, -5, 10]
        self.action_space = spaces.Tuple([spaces.Discrete(len(self.action_meaning))]*NCAP )      # need to add cap value
        low_space=np.array([VDI_LOW] * 301)
        high_space =np.array([VDI_HIGH] * 301) 
        self.observation_space = spaces.Box(
            low = low_space  ,
            high = high_space  , dtype=np.float64)

        # initialize current param/spec observations
        self.cur_params_idx = np.zeros(NCAP, dtype=np.int32)
        self.init_vdi = None
        self.target_vdi=0
        # Get the g* (overall design spec) you want to reach
        self.global_g = VDI_TARGET
        self.init = 0
           
    def reset(self):
        if self.env_steps ==0:
            s1 = ''
            for i in range(NCAP):
                s1 += '.param dcap_int_val%d=0\n' % (i+1)
            f = open(PATH_PREFIX + str(os.getpid()) + '_int_param_dcap.txt', 'w')
            f.write(s1)
            f.close()
            run_os()
            
            freq_arr = readresult(str(os.getpid())+'_freq_data.txt')
            freq_val = freq_arr[:,1]
            self.ob = freq_val
            
        return self.ob
    

    def step(self, action):
        """
        :param action: is vector with elements between 0 and 1 mapped to the index of the corresponding parameter
        :return:
        """
        dict_exist = os.path.exists('%s_dict_state.npy' % str(os.getpid()) )
        if dict_exist:
            dict_state = np.load('%s_dict_state.npy' % str(os.getpid()) ,allow_pickle=True).item()
        else:
            dict_state = {}

        # Take action that RL agent returns to change current params
        action = list(np.reshape(np.array(action), (np.array(action).shape[0],)))
        self.cur_params_idx = self.cur_params_idx + np.array([self.action_meaning[a] for a in action])

        self.cur_params_idx = np.clip(self.cur_params_idx, [0]*NCAP , [100]*NCAP )
        # Get current specs and normalize


        comm='''
        if (p+str(self.cur_params_idx)) in dict_state:
            self.cur_specs = dict_state[p+str(self.cur_params_idx)]
        else:
            self.cur_specs = self.update(self.cur_params_idx)   # update state=144
            dict_state[p+str(self.cur_params_idx)] = self.cur_specs
        #'''
        self.cur_specs = self.update(self.cur_params_idx)	# updated frequency value after changing dcap value,shape = (301,)
               
        reward = self.reward(self.cur_specs,self.cur_params_idx)
      
        done = False
        #np.save('%s_dict_state.npy'%str(os.getpid()) ,dict_state)
        
        #cur_spec_norm1 = np.array(cur_spec_norm)
        
        self.ob = np.array(self.cur_specs)
        self.env_steps = self.env_steps + 1
        
        with open(PATH_PREFIX + str(os.getpid()) + '_' + 'reward_plot', 'a') as f:
            strs = f'total impedance={np.sum(self.cur_specs)} V*s   reward={reward} steps={self.env_steps}\n'
            #lines += strs
            f.write(strs)
            f.close()
        with open(PATH_PREFIX + str(os.getpid()) + '_' + 'int_dcap.param', 'a') as f1:
            str1 = f'current decap:{self.cur_params_idx}\n'
            f1.write(str1)
            f1.close()

        # print(reward)
               
        #return self.ob, reward, done, {},self.cur_params_idx,0.05*self.init_vdi,self.cur_specs
        return self.ob, reward, done, {}



    def reward(self,freq_val,cur_param_idx):
       # reward = 1 -np.sum(spec) / self.target_vdi
        total_impe = 0
        dcap_num = 0
        for i in freq_val:
            if i > 0.1:
                total_impe += i - 0.1
        for j in cur_param_idx:
            if j > 0:
                dcap_num += 1
        total_cost = total_impe + dcap_num / len(cur_param_idx)
        
        return -total_cost   

    def update(self, params_idx):
        """

        :param action: an int between 0 ... n-1
        :return:
        """
        str_dc = ''
        #for i in range(1):
        for i,val in enumerate(params_idx):
            str_dc += '.param dcap_int_val%d=%dp\n' % (i+1,val)
        #print(str_dc)
        f = open(PATH_PREFIX + str(os.getpid()) + '_int_param_dcap.txt', 'w')
        f.write(str_dc)
        f.close()
        run_os()
        # add pid info
        state1 = readresult(str(os.getpid())+'_freq_data.txt')
        state2 = state1[:,1]
        
        return state2


def main():
    env_config = {}
    env = DecapPlaceParallel(env_config)
    
    env.reset()
    env.step([2]*NCAP)

    IPython.embed()


if __name__ == "__main__":
    print(os.getpid())
    main()
    
