import os
import time
import re

filepath = '/HDD8T/2021StudentFile/fhy/DQN/gitcode/duo_multi/duo-opt-RL10_source-inferdemo/result_fig/'
#os.system('conda activate rllib')
f = open('decap_ppo_demo.py','r')
f1 = f.readlines()
f.close()
#print(f1[62])

dirs = os.listdir(filepath)




for j in range(11,21):
    f1[62] = '    subs = %d\n' % j
    f = open('decap_ppo_demo.py','w')
    for lines in f1:
    	f.write(lines)
    f.close()
    
    
    os.system('python3 rollout.py --no-render --run PPO --traj_len 20 --env decap-v0 --num_val_specs 100 /home/fhy/ray_results/decap_rl_20230224_duo_10_sample_/PPO_DecapPlaceParallel_c7cbc_00000_0_2023-02-24_23-34-52/checkpoint_000040')
    #time.sleep(5)
    os.system('mkdir -p /HDD8T/2021StudentFile/fhy/DQN/gitcode/duo_multi/duo-opt-RL10_source-inferdemo/result_fig/train%d' % j)
    dir_name = os.path.join(filepath,'train%d' %j)
   
    for pic in dirs:
        pics = os.path.join(filepath,pic)
        if pic[0].isdigit():
            #print(dir_name)
            #print(pic)
            #print(pics)
            #print(filepath)
            os.system('mv %s %s'% (pics,dir_name))


